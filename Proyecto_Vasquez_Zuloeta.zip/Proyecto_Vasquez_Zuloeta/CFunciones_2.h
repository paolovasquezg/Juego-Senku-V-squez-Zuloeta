//
// Created by Usuario on 12/13/2021.
//

#ifndef PROYECTO_VASQUEZ_ZULOETA_CFUNCIONES_2_H
#define PROYECTO_VASQUEZ_ZULOETA_CFUNCIONES_2_H

#include <iostream>
#include <vector>
#include <ctime>
#include <map>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "CTablero.h"
#include "CFrances.h"
#include "CAleman.h"
#include "CAsimetrico.h"
#include "CIngles.h"
#include "CDiamante.h"
#include "CFunciones.h"

using namespace std;

void jugar_senku_1(int &opcion, int &modo, int &opcion2);

#endif //PROYECTO_VASQUEZ_ZULOETA_CFUNCIONES_2_H
