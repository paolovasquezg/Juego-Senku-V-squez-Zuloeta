#include "CTablero.h"
#include "CFrances.h"
#include "Windows.h"
#include "CAleman.h"
#include "CAsimetrico.h"
#include "CIngles.h"
#include "CDiamante.h"
#include "CFunciones.h"
#include "CFunciones_2.h"

int main(){

    senku();

    return 0;
}